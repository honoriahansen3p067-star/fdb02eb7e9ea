// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Block Cholesky factorize"); }
int main(){
  announce();
  return lionss_run_workload("cholesky_block");
}
