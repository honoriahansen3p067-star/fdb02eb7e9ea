// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Sum delta-V budget\n", stdout);
  return lionss_run_workload("deltaV_budget");
}
