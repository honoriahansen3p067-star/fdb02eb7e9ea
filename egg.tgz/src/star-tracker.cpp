// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Match star field\n", stdout);
  return lionss_run_workload("star-tracker");
}
