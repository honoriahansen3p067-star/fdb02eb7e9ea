// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render coverage heatmap\n", stdout);
  return lionss_run_workload("coverageHeatmap");
}
