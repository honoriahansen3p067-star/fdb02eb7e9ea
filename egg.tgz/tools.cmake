# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(occlusionPortal src/occlusionPortal.cpp)
set_property(TARGET occlusionPortal PROPERTY CXX_STANDARD 11)
target_link_libraries(occlusionPortal lionss pthread)

add_executable(nvimLsp src/nvimLsp.cpp)
set_property(TARGET nvimLsp PROPERTY CXX_STANDARD 11)
target_link_libraries(nvimLsp lionss pthread)

add_executable(VkDescriptor src/VkDescriptor.cpp)
set_property(TARGET VkDescriptor PROPERTY CXX_STANDARD 11)
target_link_libraries(VkDescriptor lionss pthread)

add_executable(svdrandomized src/svdrandomized.cpp)
set_property(TARGET svdrandomized PROPERTY CXX_STANDARD 11)
target_link_libraries(svdrandomized lionss pthread)

add_executable(indigoFox src/indigoFox.cpp)
set_property(TARGET indigoFox PROPERTY CXX_STANDARD 11)
target_link_libraries(indigoFox lionss pthread)

add_executable(graphite-owl src/graphite-owl.cpp)
set_property(TARGET graphite-owl PROPERTY CXX_STANDARD 11)
target_link_libraries(graphite-owl lionss pthread)

add_executable(duskfall src/duskfall.cpp)
set_property(TARGET duskfall PROPERTY CXX_STANDARD 11)
target_link_libraries(duskfall lionss pthread)

add_executable(Boreal src/Boreal.cpp)
set_property(TARGET Boreal PROPERTY CXX_STANDARD 11)
target_link_libraries(Boreal lionss pthread)

add_executable(DedupeSilver src/DedupeSilver.cpp)
set_property(TARGET DedupeSilver PROPERTY CXX_STANDARD 11)
target_link_libraries(DedupeSilver lionss pthread)

add_executable(deopt-guard src/deopt-guard.cpp)
set_property(TARGET deopt-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(deopt-guard lionss pthread)

add_executable(Halcyon src/Halcyon.cpp)
set_property(TARGET Halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(Halcyon lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

add_executable(RowanMoor src/RowanMoor.cpp)
set_property(TARGET RowanMoor PROPERTY CXX_STANDARD 11)
target_link_libraries(RowanMoor lionss pthread)

add_executable(mossrock src/mossrock.cpp)
set_property(TARGET mossrock PROPERTY CXX_STANDARD 11)
target_link_libraries(mossrock lionss pthread)

add_executable(canopy src/canopy.cpp)
set_property(TARGET canopy PROPERTY CXX_STANDARD 11)
target_link_libraries(canopy lionss pthread)

add_executable(orbTrack src/orbTrack.cpp)
set_property(TARGET orbTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(orbTrack lionss pthread)

add_executable(groundTrack src/groundTrack.cpp)
set_property(TARGET groundTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(groundTrack lionss pthread)

add_executable(AsciidocPdf src/AsciidocPdf.cpp)
set_property(TARGET AsciidocPdf PROPERTY CXX_STANDARD 11)
target_link_libraries(AsciidocPdf lionss pthread)

add_executable(coverageHeatmap src/coverageHeatmap.cpp)
set_property(TARGET coverageHeatmap PROPERTY CXX_STANDARD 11)
target_link_libraries(coverageHeatmap lionss pthread)

add_executable(sgd-nesterov src/sgd-nesterov.cpp)
set_property(TARGET sgd-nesterov PROPERTY CXX_STANDARD 11)
target_link_libraries(sgd-nesterov lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(deltaV_budget src/deltaV_budget.cpp)
set_property(TARGET deltaV_budget PROPERTY CXX_STANDARD 11)
target_link_libraries(deltaV_budget lionss pthread)

add_executable(biquad-lp src/biquad-lp.cpp)
set_property(TARGET biquad-lp PROPERTY CXX_STANDARD 11)
target_link_libraries(biquad-lp lionss pthread)

add_executable(apparmor_profile src/apparmor_profile.cpp)
set_property(TARGET apparmor_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(apparmor_profile lionss pthread)

add_executable(smartctl_long src/smartctl_long.cpp)
set_property(TARGET smartctl_long PROPERTY CXX_STANDARD 11)
target_link_libraries(smartctl_long lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(cholesky_block src/cholesky_block.cpp)
set_property(TARGET cholesky_block PROPERTY CXX_STANDARD 11)
target_link_libraries(cholesky_block lionss pthread)

add_executable(star-tracker src/star-tracker.cpp)
set_property(TARGET star-tracker PROPERTY CXX_STANDARD 11)
target_link_libraries(star-tracker lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(quickcheckGen src/quickcheckGen.cpp)
set_property(TARGET quickcheckGen PROPERTY CXX_STANDARD 11)
target_link_libraries(quickcheckGen lionss pthread)

